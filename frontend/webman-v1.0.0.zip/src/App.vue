<script setup lang="ts">
import MainLayout from '@/layouts/MainLayout.vue'
</script>

<template>
  <MainLayout>
    <template #main>
      <RouterView />
    </template>
  </MainLayout>
</template>
